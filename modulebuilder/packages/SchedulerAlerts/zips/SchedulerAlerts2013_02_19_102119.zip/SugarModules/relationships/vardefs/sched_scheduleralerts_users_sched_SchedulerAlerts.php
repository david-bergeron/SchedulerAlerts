<?php
// created: 2013-02-19 10:21:19
$dictionary["sched_SchedulerAlerts"]["fields"]["sched_scheduleralerts_users"] = array (
  'name' => 'sched_scheduleralerts_users',
  'type' => 'link',
  'relationship' => 'sched_scheduleralerts_users',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SCHED_SCHEDULERALERTS_USERS_FROM_USERS_TITLE',
);
