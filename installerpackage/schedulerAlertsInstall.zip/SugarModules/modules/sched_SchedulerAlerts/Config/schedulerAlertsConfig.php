<?php

$schedulerAlertsConfig = array (
	'ids' =>
		array (
			'teams' =>
			array (
			),
			'roles' =>
			array (
			),
			'users' =>
			array (
			),
		),
	'in_process_alert_duration' => '20',
	'in_process_alerts_enabled' => false,
	'in_process_scheduler_id' => '',
	'status' => 'Inactive',
);